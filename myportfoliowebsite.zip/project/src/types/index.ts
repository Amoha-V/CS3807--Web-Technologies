export interface Project {
  title: string;
  description: string;
  technologies: string[];
  githubLink?: string;
  liveLink?: string;
  image?: string;
}

export interface Experience {
  role: string;
  company: string;
  duration: string;
  location: string;
  details: string[];
}

export interface Certification {
  title: string;
  issuer?: string;
  date?: string;
  link?: string;
}

export interface SkillCategory {
  name: string;
  skills: string[];
}

export type Theme = 'light' | 'dark';