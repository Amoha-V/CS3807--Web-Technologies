import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import AnimatedBackground from './components/AnimatedBackground';
import NavBar from './components/NavBar';
import Hero from './components/sections/Hero';
import About from './components/sections/About';
import Projects from './components/sections/Projects';
import Skills from './components/sections/Skills';
import Experience from './components/sections/Experience';
import Certifications from './components/sections/Certifications';
import Contact from './components/sections/Contact';
import Footer from './components/Footer';
import CursorEffect from './components/CursorEffect';

function App() {
  const [activeSection, setActiveSection] = useState<string>('about');

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-slate-950 text-white relative">
        <AnimatedBackground />
        <CursorEffect />
        <NavBar activeSection={activeSection} setActiveSection={setActiveSection} />
        
        <main className="pt-20">
          <Hero setActiveSection={setActiveSection} />
          <About />
          <Projects />
          <Skills />
          <Experience />
          <Certifications />
          <Contact />
        </main>
        
        <Footer />
      </div>
    </ThemeProvider>
  );
}

export default App;