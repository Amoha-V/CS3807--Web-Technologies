import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Github, ExternalLink } from 'lucide-react';
import { projectsData } from '../../data/projectsData';

const Projects: React.FC = () => {
  const [ref, inView] = useInView({
    threshold: 0.1,
    triggerOnce: true
  });
  
  const [filter, setFilter] = useState<string>('All');
  const [activeProject, setActiveProject] = useState<number | null>(null);
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  // Extract unique technologies for filter
  const allTechnologies = new Set<string>();
  projectsData.forEach(project => {
    project.technologies.forEach(tech => allTechnologies.add(tech));
  });
  
  const filters = ['All', 'AI & ML', 'Web Development', 'IoT', 'Python'];

  const filteredProjects = filter === 'All' 
    ? projectsData 
    : projectsData.filter(project => {
        if (filter === 'AI & ML') {
          return project.technologies.some(tech => 
            ['Machine Learning', 'Deep Learning', 'AI', 'Neural Networks', 'NLP', 
             'Computer Vision', 'GAN', 'SRGAN'].includes(tech)
          );
        }
        if (filter === 'Web Development') {
          return project.technologies.some(tech => 
            ['React', 'Node.js', 'Express.js', 'HTML', 'CSS', 'JavaScript'].includes(tech)
          );
        }
        if (filter === 'IoT') {
          return project.technologies.some(tech => 
            ['Arduino', 'IoT'].includes(tech)
          );
        }
        if (filter === 'Python') {
          return project.technologies.includes('Python');
        }
        return false;
      });

  return (
    <section id="projects" className="py-20 px-6 min-h-screen">
      <motion.div 
        ref={ref}
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="container mx-auto max-w-6xl"
      >
        <motion.h2 
          variants={itemVariants}
          className="text-4xl md:text-5xl font-bold mb-12 text-center text-mint"
        >
          Projects & Innovations
        </motion.h2>
        
        <motion.div 
          variants={itemVariants}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {filters.map(filterOption => (
            <motion.button
              key={filterOption}
              onClick={() => setFilter(filterOption)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-4 py-2 rounded-full text-sm font-medium ${
                filter === filterOption 
                ? 'bg-mint text-slate-900' 
                : 'bg-slate-800/60 text-white/80 hover:text-white'
              }`}
            >
              {filterOption}
            </motion.button>
          ))}
        </motion.div>
        
        <motion.div 
          variants={containerVariants}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {filteredProjects.map((project, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ 
                scale: 1.02,
                boxShadow: "0 10px 30px -10px rgba(0, 0, 0, 0.3)" 
              }}
              className={`relative bg-slate-800/40 backdrop-blur-sm rounded-2xl overflow-hidden border border-slate-700 shadow-lg transform transition-all duration-300 ${
                activeProject === index ? 'h-auto' : 'h-auto'
              }`}
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-mint via-lilac to-skyblue" />
              
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3 text-white">{project.title}</h3>
                <p className="text-white/80 text-sm mb-4 line-clamp-3">{project.description}</p>
                
                <div className="flex gap-3 mb-4">
                  {project.githubLink && (
                    <a 
                      href={project.githubLink} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center text-xs px-3 py-1.5 bg-slate-700/60 hover:bg-slate-700 text-white rounded-full transition-colors"
                    >
                      <Github className="mr-1" size={14} />
                      GitHub
                    </a>
                  )}
                  
                  {project.liveLink && (
                    <a 
                      href={project.liveLink} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center text-xs px-3 py-1.5 bg-mint/90 hover:bg-mint text-slate-900 rounded-full transition-colors"
                    >
                      <ExternalLink className="mr-1" size={14} />
                      Live Demo
                    </a>
                  )}
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {project.technologies.slice(0, 3).map((tech, idx) => (
                    <span
                      key={idx}
                      className="text-xs px-2 py-1 rounded-full bg-slate-700/60 text-white/90"
                    >
                      {tech}
                    </span>
                  ))}
                  {project.technologies.length > 3 && (
                    <span className="text-xs px-2 py-1 rounded-full bg-slate-700/60 text-white/90">
                      +{project.technologies.length - 3}
                    </span>
                  )}
                </div>
                
                <motion.button
                  onClick={() => setActiveProject(activeProject === index ? null : index)}
                  className="mt-4 text-mint text-sm hover:underline"
                >
                  {activeProject === index ? "Show Less" : "Show More"}
                </motion.button>
                
                <AnimatePresence>
                  {activeProject === index && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                      className="mt-4 pt-4 border-t border-slate-700"
                    >
                      <h4 className="text-sm font-medium text-white mb-2">All Technologies:</h4>
                      <div className="flex flex-wrap gap-2">
                        {project.technologies.map((tech, idx) => (
                          <span
                            key={idx}
                            className="text-xs px-2 py-1 rounded-full bg-slate-700/60 text-white/90"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Projects;