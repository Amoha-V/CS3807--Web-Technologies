import React from 'react';
import { motion } from 'framer-motion';
import { Github, Linkedin, Mail, ChevronDown } from 'lucide-react';

interface HeroProps {
  setActiveSection: (section: string) => void;
}

const Hero: React.FC<HeroProps> = ({ setActiveSection }) => {
  return (
    <section className="relative min-h-screen flex flex-col justify-center items-center px-6 overflow-hidden">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="text-center max-w-3xl"
      >
        <motion.h1 
          className="text-4xl md:text-6xl lg:text-7xl font-bold text-white tracking-tight leading-tight mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Hi, I'm <span className="text-mint">Amoha Vivekananthan</span>
        </motion.h1>
        
        <motion.h2 
          className="text-xl md:text-2xl text-white/80 mb-8 tracking-wide"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          Computer Science Engineer, AI Enthusiast & Web Developer
        </motion.h2>
        
        <motion.div 
          className="flex justify-center space-x-6 mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <motion.a
            href="https://github.com/Amoha-V"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.1, y: -5 }}
            whileTap={{ scale: 0.9 }}
            className="p-3 rounded-full bg-slate-800/60 text-white hover:text-mint hover:bg-slate-800/90 transition-all duration-300"
          >
            <Github size={20} />
          </motion.a>
          <motion.a
            href="https://linkedin.com/in/amohav"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.1, y: -5 }}
            whileTap={{ scale: 0.9 }}
            className="p-3 rounded-full bg-slate-800/60 text-white hover:text-mint hover:bg-slate-800/90 transition-all duration-300"
          >
            <Linkedin size={20} />
          </motion.a>
          <motion.a
            href="mailto:info@amohav.com"
            whileHover={{ scale: 1.1, y: -5 }}
            whileTap={{ scale: 0.9 }}
            className="p-3 rounded-full bg-slate-800/60 text-white hover:text-mint hover:bg-slate-800/90 transition-all duration-300"
          >
            <Mail size={20} />
          </motion.a>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.9 }}
        >
          <motion.button
            onClick={() => setActiveSection('about')}
            className="px-8 py-3 rounded-full bg-mint text-slate-900 font-semibold tracking-wide hover:bg-white transition-all duration-300"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Explore My Work
          </motion.button>
        </motion.div>
      </motion.div>
      
      <motion.div 
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 1.2, repeat: Infinity, repeatType: "reverse" }}
      >
        <ChevronDown size={32} className="text-mint animate-bounce" />
      </motion.div>
    </section>
  );
};

export default Hero;