import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { certificationsData } from '../../data/certificationsData';
import { Award } from 'lucide-react';

const Certifications: React.FC = () => {
  const [ref, inView] = useInView({
    threshold: 0.1,
    triggerOnce: true
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <section id="certifications" className="py-20 px-6 min-h-screen">
      <motion.div 
        ref={ref}
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="container mx-auto max-w-6xl"
      >
        <motion.h2 
          variants={itemVariants}
          className="text-4xl md:text-5xl font-bold mb-12 text-center text-mint"
        >
          Certifications & Achievements
        </motion.h2>
        
        <motion.div 
          variants={containerVariants}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {certificationsData.map((cert, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ scale: 1.03, y: -5 }}
              className="bg-slate-800/40 backdrop-blur-sm p-5 rounded-2xl border border-slate-700 shadow-lg flex items-center"
            >
              <Award className="mr-4 text-mint flex-shrink-0" size={24} />
              <div>
                <h3 className="font-medium text-white">{cert.title}</h3>
                {cert.issuer && <p className="text-white/70 text-sm">{cert.issuer}</p>}
                {cert.date && <p className="text-white/60 text-xs">{cert.date}</p>}
                
                {cert.link && (
                  <a 
                    href={cert.link} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-mint text-xs hover:underline mt-1 inline-block"
                  >
                    View Certificate
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Certifications;