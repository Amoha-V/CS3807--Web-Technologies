import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { experienceData } from '../../data/experienceData';
import { Briefcase, MapPin, Calendar } from 'lucide-react';

const Experience: React.FC = () => {
  const [ref, inView] = useInView({
    threshold: 0.1,
    triggerOnce: true
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <section id="experience" className="py-20 px-6 min-h-screen">
      <motion.div 
        ref={ref}
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="container mx-auto max-w-4xl"
      >
        <motion.h2 
          variants={itemVariants}
          className="text-4xl md:text-5xl font-bold mb-12 text-center text-mint"
        >
          Professional Experience
        </motion.h2>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-0.5 bg-slate-700" />
          
          {experienceData.map((exp, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className={`relative mb-12 md:mb-16 ${
                index % 2 === 0 ? 'md:pr-12 md:text-right md:ml-auto md:mr-0' : 'md:pl-12 md:text-left md:ml-0 md:mr-auto'
              } md:w-1/2 z-10`}
            >
              {/* Timeline dot */}
              <div className={`absolute top-0 ${
                index % 2 === 0 ? 'left-0 md:-left-2.5' : 'left-0 md:-left-2.5 md:left-auto md:-right-2.5'
              } w-5 h-5 rounded-full bg-mint`} />
              
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="bg-slate-800/40 backdrop-blur-sm p-6 rounded-2xl border border-slate-700 shadow-lg"
              >
                <h3 className="text-xl font-semibold text-white mb-2">{exp.role}</h3>
                <p className="text-mint flex items-center mb-2">
                  <Briefcase size={16} className="mr-2" />
                  {exp.company}
                </p>
                
                <div className="flex flex-wrap gap-4 mb-4 text-sm text-white/80">
                  <span className="flex items-center">
                    <Calendar size={14} className="mr-1" />
                    {exp.duration}
                  </span>
                  <span className="flex items-center">
                    <MapPin size={14} className="mr-1" />
                    {exp.location}
                  </span>
                </div>
                
                <ul className="list-disc list-inside text-white/90 space-y-1 text-sm">
                  {exp.details.map((detail, i) => (
                    <li key={i}>{detail}</li>
                  ))}
                </ul>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
};

export default Experience;