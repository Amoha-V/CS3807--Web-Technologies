import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Mail, Github, Linkedin, Send } from 'lucide-react';

const Contact: React.FC = () => {
  const [ref, inView] = useInView({
    threshold: 0.1,
    triggerOnce: true
  });
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');
    
    // Simulating form submission
    setTimeout(() => {
      setFormStatus('success');
      setFormData({ name: '', email: '', message: '' });
      
      // Reset form status after 3 seconds
      setTimeout(() => {
        setFormStatus('idle');
      }, 3000);
    }, 1500);
  };

  return (
    <section id="contact" className="py-20 px-6 min-h-screen">
      <motion.div 
        ref={ref}
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="container mx-auto max-w-5xl"
      >
        <motion.h2 
          variants={itemVariants}
          className="text-4xl md:text-5xl font-bold mb-12 text-center text-mint"
        >
          Get In Touch
        </motion.h2>
        
        <div className="flex flex-col md:flex-row gap-12">
          <motion.div 
            variants={itemVariants}
            className="w-full md:w-2/5"
          >
            <h3 className="text-2xl font-semibold text-white mb-6">Let's Connect</h3>
            <p className="text-white/80 mb-8">
              Feel free to reach out if you're looking for a developer, have a question, or just want to connect.
            </p>
            
            <div className="space-y-6">
              <motion.a
                href="mailto:info@amohav.com"
                className="flex items-center text-white/90 hover:text-mint transition-colors"
                whileHover={{ x: 5 }}
              >
                <div className="w-12 h-12 rounded-full bg-slate-800/60 flex items-center justify-center mr-4">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="font-medium">Email</h4>
                  <p className="text-sm text-white/70">info@amohav.com</p>
                </div>
              </motion.a>
              
              <motion.a
                href="https://github.com/Amoha-V"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-white/90 hover:text-mint transition-colors"
                whileHover={{ x: 5 }}
              >
                <div className="w-12 h-12 rounded-full bg-slate-800/60 flex items-center justify-center mr-4">
                  <Github size={20} />
                </div>
                <div>
                  <h4 className="font-medium">GitHub</h4>
                  <p className="text-sm text-white/70">github.com/Amoha-V</p>
                </div>
              </motion.a>
              
              <motion.a
                href="https://linkedin.com/in/amohav"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-white/90 hover:text-mint transition-colors"
                whileHover={{ x: 5 }}
              >
                <div className="w-12 h-12 rounded-full bg-slate-800/60 flex items-center justify-center mr-4">
                  <Linkedin size={20} />
                </div>
                <div>
                  <h4 className="font-medium">LinkedIn</h4>
                  <p className="text-sm text-white/70">linkedin.com/in/amohav</p>
                </div>
              </motion.a>
            </div>
          </motion.div>
          
          <motion.div 
            variants={itemVariants}
            className="w-full md:w-3/5"
          >
            <form onSubmit={handleSubmit} className="bg-slate-800/40 backdrop-blur-sm p-8 rounded-2xl border border-slate-700 shadow-lg">
              <div className="mb-6">
                <label htmlFor="name" className="block text-white/90 mb-2 text-sm">Your Name</label>
                <motion.div
                  whileFocus={{ scale: 1.01 }}
                  className="relative"
                >
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-slate-900/60 border border-slate-700 rounded-lg text-white placeholder:text-white/50 focus:outline-none focus:border-mint transition-colors"
                    placeholder="John Doe"
                  />
                  <div className="absolute bottom-0 left-0 h-0.5 bg-mint transform origin-left scale-x-0 transition-transform duration-300 group-focus-within:scale-x-100" />
                </motion.div>
              </div>
              
              <div className="mb-6">
                <label htmlFor="email" className="block text-white/90 mb-2 text-sm">Your Email</label>
                <motion.div
                  whileFocus={{ scale: 1.01 }}
                  className="relative"
                >
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-slate-900/60 border border-slate-700 rounded-lg text-white placeholder:text-white/50 focus:outline-none focus:border-mint transition-colors"
                    placeholder="john@example.com"
                  />
                  <div className="absolute bottom-0 left-0 h-0.5 bg-mint transform origin-left scale-x-0 transition-transform duration-300 group-focus-within:scale-x-100" />
                </motion.div>
              </div>
              
              <div className="mb-6">
                <label htmlFor="message" className="block text-white/90 mb-2 text-sm">Your Message</label>
                <motion.div
                  whileFocus={{ scale: 1.01 }}
                  className="relative"
                >
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 bg-slate-900/60 border border-slate-700 rounded-lg text-white placeholder:text-white/50 focus:outline-none focus:border-mint transition-colors resize-none"
                    placeholder="Hi Amoha, I'd like to talk about..."
                  />
                  <div className="absolute bottom-0 left-0 h-0.5 bg-mint transform origin-left scale-x-0 transition-transform duration-300 group-focus-within:scale-x-100" />
                </motion.div>
              </div>
              
              <motion.button
                type="submit"
                disabled={formStatus === 'submitting' || formStatus === 'success'}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`px-6 py-3 rounded-lg flex items-center justify-center text-slate-900 font-medium ${
                  formStatus === 'success' 
                    ? 'bg-green-400'
                    : 'bg-mint hover:bg-mint/90'
                } transition-colors w-full`}
              >
                {formStatus === 'submitting' ? (
                  <span className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-slate-900\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                      <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Sending...
                  </span>
                ) : formStatus === 'success' ? (
                  <span className="flex items-center">
                    Message Sent Successfully!
                  </span>
                ) : (
                  <span className="flex items-center">
                    <Send size={18} className="mr-2" />
                    Send Message
                  </span>
                )}
              </motion.button>
              
              {formStatus === 'error' && (
                <p className="mt-3 text-red-400 text-sm">
                  There was an error sending your message. Please try again.
                </p>
              )}
            </form>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};

export default Contact;