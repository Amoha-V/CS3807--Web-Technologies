import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Sparkles, Code, Award, Cpu } from 'lucide-react';

const About: React.FC = () => {
  const [ref, inView] = useInView({
    threshold: 0.2,
    triggerOnce: true
  });
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <section id="about" className="py-20 px-6 min-h-screen flex items-center">
      <motion.div 
        ref={ref}
        variants={containerVariants}
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        className="container mx-auto max-w-5xl"
      >
        <motion.div
          variants={itemVariants}
          className="flex flex-col gap-12 items-center"
        >
          <div className="w-full">
            <motion.h2 
              variants={itemVariants}
              className="text-4xl md:text-5xl font-bold mb-8 text-mint flex items-center"
            >
              <Sparkles className="mr-4 text-mint" size={28} /> About Me
            </motion.h2>
            
            <motion.div 
              variants={itemVariants}
              className="text-lg text-white/90 space-y-4"
            >
              <p className="leading-relaxed">
                <strong className="text-mint">Passionate about working with ML, Deep Learning and Generative AI.</strong>
              </p>
              
              <p className="leading-relaxed">
                I am a promising computer science student at Shiv Nadar University, specializing in IoT. With a strong academic record (CGPA 9.36), I have gained valuable industry experience through internship at Valeo India.
              </p>
              
              <p className="leading-relaxed">
                My technical skills span programming languages, AI/ML, deep learning, and web development. I'm proficient in Python, C, MySQL, React, Node.js, and more.
              </p>
              
              <p className="leading-relaxed">
                Beyond academics, I'm actively involved in the university community as a student ambassador and core committee member of the Robotics Club. I also enjoy a range of hobbies, including fashion sketching, painting, reading, and badminton.
              </p>
            </motion.div>
            
            <motion.div 
              variants={itemVariants}
              className="flex flex-wrap gap-4 mt-8"
            >
              <motion.span 
                whileHover={{ scale: 1.05 }}
                className="bg-slate-800/60 text-mint px-5 py-3 rounded-full flex items-center text-base font-medium"
              >
                <Code className="mr-2" size={18} /> Problem Solver
              </motion.span>
              
              <motion.span 
                whileHover={{ scale: 1.05 }}
                className="bg-slate-800/60 text-mint px-5 py-3 rounded-full flex items-center text-base font-medium"
              >
                <Award className="mr-2" size={18} /> Impactful Solutions
              </motion.span>
              
              <motion.span 
                whileHover={{ scale: 1.05 }}
                className="bg-slate-800/60 text-mint px-5 py-3 rounded-full flex items-center text-base font-medium"
              >
                <Cpu className="mr-2" size={18} /> AI Enthusiast
              </motion.span>
            </motion.div>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
};

export default About;