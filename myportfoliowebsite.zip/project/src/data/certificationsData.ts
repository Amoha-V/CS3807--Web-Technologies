import { Certification } from '../types';

export const certificationsData: Certification[] = [
  {
    title: "Winner at Envithon'24: Shiv Nadar University"
  },
  {
    title: "Winner at Hackathon, Itrix'25: Anna University CEG Campus"
  },
  {
    title: "Winner at Innovate-X'25 National level Hackathon: SSNCE"
  },
  {
    title: "Finalist at Shastra'25 Uzhavu hackathon: Among 500+ teams, IITM"
  },
  {
    title: "February 2025 Leetcoding Challenge Completion"
  },
  {
    title: "Top 1% at Cyber Security and Privacy: 12-Week Course from IITM"
  },
  {
    title: "Hackfest 3rd Edition, PSG iTech and SAP - Participant"
  },
  {
    title: "Top performer in Machine Learning Trainings (Internshala)"
  },
  {
    title: "Machine Learning Operations (Google Cloud Skills Boost)"
  },
  {
    title: "Neural Networks and Deep Learning (Deeplearning.ai)"
  },
  {
    title: "GUVI – SWAI.AI Learnathon- RAG Model Certification"
  }
];