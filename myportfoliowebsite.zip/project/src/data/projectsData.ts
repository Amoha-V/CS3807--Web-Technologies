import { Project } from '../types';

export const projectsData: Project[] = [
  {
    title: "AudioTales",
    description: "An Edtech tool designed for transforming images into narrated adventures using Generative AI that captivate and educate.",
    technologies: ["Generative AI", "Natural Language Processing", "Text-to-Speech", "Computer Vision"],
    githubLink: "https://github.com/Amoha-V/AudioTales",
  },
  {
    title: "Appearance – Chrome Extension",
    description: "Chrome extension to toggle between light/dark modes using JavaScript and JSON manifest.",
    technologies: ["JavaScript", "HTML", "CSS", "JSON"],
    githubLink: "https://github.com/Amoha-V/darkmode-extension",
  },
  {
    title: "YouTube AI Assistant",
    description: "Automates transcription and question answering for YouTube videos using Whisper and RoBERTa. Downloads audio, transcribes speech, and answers user queries based on extracted text.",
    technologies: ["Python", "Whisper", "RoBERTa", "Hugging Face", "YouTube API"],
    githubLink: "https://github.com/Amoha-V/yt-ai-assistant",
  },
  {
    title: "Autocomplete and Search Suggestion System",
    description: "Developed an N-gram based autocomplete system with configurable parameters. Implemented Kneser-Ney and Laplace smoothing techniques for handling sparse data.",
    technologies: ["Python", "NLP", "Kneser-Ney", "Laplace Smoothing", "Streamlit"],
    githubLink: "https://github.com/Amoha-V/Autocomplete-and-Search-Suggestion-System-using-ngram",
  },
  {
    title: "GAN-Demo",
    description: "A demonstration of Super Resolution Generative Adversarial Networks (SRGAN) technology for image enhancement and upscaling.",
    technologies: ["Python", "GAN", "SRGAN", "Deep Learning", "Image Processing"],
    githubLink: "https://github.com/Amoha-V/GAN-Demo"
  },
  {
    title: "Fertilizer Optimizer",
    description: "AI-powered tool providing tailored fertilizer recommendations to enhance crop yield and sustainability.",
    technologies: ["Python", "AI", "Machine Learning", "Flask", "HTML", "CSS"],
    githubLink: "https://github.com/Amoha-V/Fertilizer_optimizer",
  },
  {
    title: "CryptoPrice Tracker",
    description: "Web application that allows users to track cryptocurrency prices, set price alerts, and view historical price charts using the CoinGecko API",
    technologies: ["Python", "Flask", "HTML", "CSS", "JavaScript", "Plotly"],
    githubLink: "https://github.com/Amoha-V/Crypto-Price-Tracker",
  },
  {
    title: "SMS Spam Detection using NLP",
    description: "Machine learning application using Natural Language Processing to classify SMS messages as spam or ham.",
    technologies: ["Python", "Streamlit", "Scikit-learn", "NLTK", "NLP"],
    githubLink: "https://github.com/Amoha-V/NLP",
  },
  {
    title: "IoT Based Voice Controlled Home Automation",
    description: "Arduino-based system enabling voice-controlled home appliance management, increasing accessibility.",
    technologies: ["Arduino", "Bluetooth", "Voice Recognition", "IoT"],
    githubLink: "https://github.com/Amoha-V/CS1702-Introduction-To-Internet-of-things-Lab",
  },
  {
    title: "Fall Detection System",
    description: "Video-based fall detection using YOLO object detection for non-intrusive real-time monitoring.",
    technologies: ["Python", "YOLO", "Computer Vision", "Machine Learning"],
  },
  {
    title: "Book Scraper Project",
    description: "Python-based web scraper that extracts book data from the Books to Scrape website including title, price, and ratings.",
    technologies: ["Python", "Requests", "BeautifulSoup", "Pandas", "Web Scraping"],
    githubLink: "https://github.com/Amoha-V/Web-Scraper",
  },
  {
    title: "Vehicle Rental Management System",
    description: "Full-stack web application with responsive UI, user authentication, and MySQL database integration.",
    technologies: ["Node.js", "Express.js", "MySQL", "HTML", "CSS", "JavaScript"],
    githubLink: "https://github.com/Amoha-V/Vehicle-Rental-and-Services-Management-DBMS",
  }
];