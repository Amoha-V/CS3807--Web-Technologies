import { SkillCategory } from '../types';

export const skillsData: SkillCategory[] = [
  {
    name: "Programming Languages",
    skills: [
      "Python", "C", "MySQL", "JavaScript", 
      "Java", "HTML", "CSS"
    ]
  },
  {
    name: "AI & Machine Learning",
    skills: [
      "Machine Learning", 
      "Deep Learning", 
      "Neural Networks", 
      "Computer Vision", 
      "Ensemble Models",
      "Large Language Models",
      "CNN",
      "Stable Diffusion"
    ]
  },
  {
    name: "Web Development",
    skills: [
      "React", 
      "Node.js", 
      "Express.js", 
      "MongoDB", 
      "TailwindCSS", 
      "Bootstrap",
      "MERN Stack"
    ]
  },
  {
    name: "Tools",
    skills: [
      "VS Code", 
      "Jupyter", 
      "Git", 
      "Neptune.ai"
    ]
  },
  {
    name: "Generative AI",
    skills: [
      "Deep Learning",
      "NLP",
      "Transformers",
      "LLMs",
      "Generative Adversarial Networks",
      "Stable Diffusion Model",
      "RAG"
    ]
  },
  {
    name: "Data Visualization",
    skills: [
      "Matplotlib", 
      "Dash", 
      "Streamlit", 
      "Google Looker Studio"
    ]
  },
  {
    name: "Platforms",
    skills: [
      "Arduino", 
      "IoT", 
      "Cloud Skills Boost"
    ]
  }
];