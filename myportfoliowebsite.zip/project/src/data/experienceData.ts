import { Experience } from '../types';

export const experienceData: Experience[] = [
  {
    role: "Software Development Intern",
    company: "Valeo India - Brain Division",
    duration: "Jun-Jul 2024",
    location: "Chennai",
    details: [
      "Developed APN GT Data Analysis Dashboard for Bird Eye Vision.",
      "Applied SOLID Principles for scalable, maintainable code.",
      "Created a pipeline for processing GT raw data with MTN constraints.",
      "Collaborated with cross-functional teams to optimize data processing workflows."
    ]
  },
  {
    role: "Student Ambassador",
    company: "Shiv Nadar University",
    duration: "Aug 2024 - Present",
    location: "Chennai",
    details: [
      "Represented university at various academic and cultural events.",
      "Assisted in student recruitment and campus engagement initiatives."
    ]
  },
  {
    role: "Core Committee Member (Software Domain)",
    company: "Robotics Club, SNU Chennai",
    duration: "Aug 2024 - Present",
    location: "Chennai",
    details: [
      "Conducted Arduino Uno workshops and hackathon events.",
      "Led technical sessions on robotics and embedded systems.",
      "Mentored junior students in software and robotics projects."
    ]
  },
  {
    role: "Campus Ambassador",
    company: "GeeksforGeeks",
    duration: "Dec 2024 - Present",
    location: "Chennai",
    details: [
      "Represented university at various academic and cultural events."
    ]
  }
];